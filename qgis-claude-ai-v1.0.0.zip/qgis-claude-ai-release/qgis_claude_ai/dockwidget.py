# -*- coding: utf-8 -*-
"""
Dock Widget principal - Interface de chat
"""
import json
from qgis.PyQt.QtWidgets import (
    QDockWidget, QVBoxLayout, QWidget, QTextEdit, QLineEdit,
    QPushButton, QHBoxLayout, QLabel, QComboBox, QMessageBox
)
from qgis.PyQt.QtCore import Qt, pyqtSignal, QThread, QObject
from qgis.core import QgsProject, QgsMessageLog

from .executor import execute_claude_plan


class WorkerSignals(QObject):
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)
    progress = pyqtSignal(str)


class ClaudeWorker(QThread):
    """Thread para não travar a UI do QGIS."""
    def __init__(self, claude_client, prompt, context_layers):
        super().__init__()
        self.claude_client = claude_client
        self.prompt = prompt
        self.context_layers = context_layers
        self.signals = WorkerSignals()

    def run(self):
        try:
            # 1. Pede plano à IA (Anthropic → OpenRouter → Mock)
            plan = self.claude_client.ask_claude(self.prompt, self.context_layers)
            self.signals.progress.emit(f"Plano recebido: {len(plan.get('steps', []))} passo(s)")

            # 2. Executa plano no QGIS
            results = execute_claude_plan(plan)
            self.signals.finished.emit({"plan": plan, "results": results})
        except Exception as e:
            import traceback
            self.signals.error.emit(traceback.format_exc())


class ClaudeAIDockWidget(QDockWidget):
    closed = pyqtSignal()

    def __init__(self, iface, claude_client):
        super().__init__("Claude AI Assistant", iface.mainWindow())
        self.iface = iface
        self.claude_client = claude_client
        self.worker = None
        self.setup_ui()

    def setup_ui(self):
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setMinimumWidth(380)

        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        # Header
        header = QHBoxLayout()
        header.addWidget(QLabel("🤖"))
        header.addWidget(QLabel("<b>Claude no QGIS</b>"))
        header.addStretch()
        layout.addLayout(header)

        # Lista de camadas (contexto)
        self.layer_combo = QComboBox()
        self.layer_combo.addItem("Todas as camadas")
        self.refresh_layers()
        layout.addWidget(QLabel("Contexto:"))
        layout.addWidget(self.layer_combo)

        # Chat area
        self.chat_log = QTextEdit()
        self.chat_log.setReadOnly(True)
        self.chat_log.setStyleSheet("""
            QTextEdit { background: #1e1e1e; color: #d4d4d4; font-family: Consolas, monospace; font-size: 12px; }
        """)
        layout.addWidget(self.chat_log)

        # Input area
        input_layout = QHBoxLayout()
        self.prompt_input = QLineEdit()
        self.prompt_input.setPlaceholderText("Ex: 'Crie buffer de 100m na camada vias e salve como buffer_vias'")
        self.prompt_input.returnPressed.connect(self.send_prompt)
        input_layout.addWidget(self.prompt_input)

        self.send_btn = QPushButton("Enviar")
        self.send_btn.clicked.connect(self.send_prompt)
        input_layout.addWidget(self.send_btn)
        layout.addLayout(input_layout)

        # Status
        self.status_label = QLabel("Pronto. Digite um comando acima.")
        self.status_label.setStyleSheet("color: #888; font-size: 11px;")
        layout.addWidget(self.status_label)

        self.setWidget(main_widget)

    def refresh_layers(self):
        self.layer_combo.clear()
        self.layer_combo.addItem("Todas as camadas")
        for layer in QgsProject.instance().mapLayers().values():
            self.layer_combo.addItem(layer.name(), layer.id())

    def get_context_layers(self):
        if self.layer_combo.currentIndex() == 0:
            return [l.name() for l in QgsProject.instance().mapLayers().values()]
        return [self.layer_combo.currentText()]

    def send_prompt(self):
        prompt = self.prompt_input.text().strip()
        if not prompt:
            return

        self.prompt_input.clear()
        self.append_chat("👤 Você", prompt)
        self.status_label.setText("Enviando para Claude...")
        self.send_btn.setEnabled(False)

        # Inicia worker
        self.worker = ClaudeWorker(self.claude_client, prompt, self.get_context_layers())
        self.worker.signals.finished.connect(self.on_worker_finished)
        self.worker.signals.error.connect(self.on_worker_error)
        self.worker.signals.progress.connect(self.on_worker_progress)
        self.worker.start()

    def on_worker_progress(self, msg):
        self.status_label.setText(msg)

    def on_worker_finished(self, data):
        self.send_btn.setEnabled(True)
        plan = data["plan"]
        results = data["results"]

        self.append_chat("🤖 Claude", f"Plano: {json.dumps(plan, ensure_ascii=False, indent=2)}")

        for i, res in enumerate(results):
            if res.get("success"):
                self.append_chat("✅", f"Passo {i+1}: {res.get('result', 'OK')}")
            else:
                self.append_chat("❌", f"Passo {i+1} FALHOU: {res.get('error')}")

        self.status_label.setText("Concluído.")

    def on_worker_error(self, err):
        self.send_btn.setEnabled(True)
        self.append_chat("❌ Erro", err)
        self.status_label.setText("Erro - veja log.")

    def append_chat(self, sender, text):
        self.chat_log.append(f"<b>{sender}:</b> {text}")
        # Auto-scroll
        self.chat_log.verticalScrollBar().setValue(
            self.chat_log.verticalScrollBar().maximum()
        )

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.terminate()
            self.worker.wait()
        self.closed.emit()
        super().closeEvent(event)