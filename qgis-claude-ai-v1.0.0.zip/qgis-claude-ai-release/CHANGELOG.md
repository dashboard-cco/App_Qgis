# Changelog

## [1.0.0] — 2026-11-16

Primeira versão publicada.

### Adicionado
- Painel de chat no QGIS para pedir ações em linguagem natural.
- Cliente de IA multi-provider: Anthropic → OpenRouter → Mock, com fallback
  automático quando um provedor falha.
- Descoberta automática de modelo gratuito na OpenRouter (não depende mais de um
  nome de modelo fixo).
- 29 ações registradas cobrindo camadas, geoprocessamento vetorial, layout/exportação
  e expressões/atributos.
- Acesso genérico a qualquer algoritmo do Processing do QGIS via `list_algorithms` /
  `run_algorithm`.

### Corrigido
- Incompatibilidade de nome de método (`ask` vs `ask_claude`) entre `dockwidget.py` e
  `ai_client.py`.
- Modelo Anthropic desatualizado e parâmetro `temperature` incompatível com o SDK
  atual.
- Resquício de código do provedor Gemini (antigo) em `__init__.py`, substituído por
  checagem das variáveis `ANTHROPIC_API_KEY` / `OPENROUTER_API_KEY`.
- Ações descritas no prompt da IA mas não registradas na lista branca do executor
  (causavam "Ação não permitida").
