# Documentação do projeto — Claude AI Assistant para QGIS

Este documento registra, em ordem, tudo que foi feito neste plugin até a versão
**v1.0.0**: decisões de arquitetura, bugs encontrados e corrigidos, e o estado final
do código. Serve como referência para quem for mexer no projeto depois.

---

## 1. Visão geral da arquitetura

```
qgis_claude_ai/
├── __init__.py         # Ponto de entrada do plugin (classFactory, menu, toolbar)
├── dockwidget.py        # Painel de chat (UI) + worker thread assíncrono
├── ai_client.py         # Cliente de IA multi-provider (Anthropic → OpenRouter → Mock)
├── executor.py          # Lista branca de ações + executor do plano JSON
├── actions/
│   ├── layers.py         # Ações sobre camadas (adicionar, remover, exportar, zoom...)
│   ├── processing.py     # Ações de geoprocessamento (buffer, clip, dissolve...) +
│   │                       acesso genérico a qualquer algoritmo do Processing
│   ├── layout.py         # Exportação de layouts/mapas (PDF, imagem)
│   └── expressions.py    # Cálculo de campos e filtros por expressão
├── metadata.txt          # Metadados do plugin QGIS
├── requirements.txt       # Dependências Python (anthropic, openai)
└── icon.svg
```

Fluxo de uma mensagem do usuário:

1. `dockwidget.py` captura o texto digitado e as camadas de contexto selecionadas.
2. Um `ClaudeWorker` (QThread) chama `ai_client.AIClient.ask_claude(prompt, camadas)`
   para não travar a interface do QGIS.
3. `ai_client.py` tenta os provedores em ordem (ver seção 3) e devolve um JSON no
   formato `{"steps": [{"action": "...", "params": {...}}, ...]}`.
4. `executor.execute_claude_plan(plan)` valida cada ação contra o dicionário
   `ACTIONS` e chama a função Python correspondente com `**params`.
5. O resultado de cada passo (sucesso/erro) é exibido no chat.

---

## 2. Histórico do projeto

### 2.1 Origem: migração de Anthropic para Gemini (sessão anterior)

O plugin começou usando a API da Anthropic diretamente. Houve uma primeira migração
para a API Gemini do Google, que passou por vários problemas de disponibilidade de
modelo:

- `models/gemini-flash-latest` → erro 404 (não existe nessa versão da API).
- `gemini-2.5-flash` → funcionou brevemente, depois passou a dar erro de que não
  está mais disponível para novos usuários.
- `gemini-3.8-flash` (sugestão da própria API) → `503 UNAVAILABLE` (sobrecarregado)
  repetidamente.
- `gemini-3.5-flash` → confirmado funcionando via teste direto no console.

Essa migração para Gemini acabou sendo **substituída** pela arquitetura
multi-provider descrita abaixo, então hoje o Gemini não é mais usado pelo plugin
(o `__init__.py` ainda tinha um resquício de código mencionando `GEMINI_API_KEY`,
que foi corrigido — ver seção 2.4).

### 2.2 Pedido do usuário: fallback automático quando a IA principal falhar

> "tem como colocar outra api pra ficar de segunda quando a do google ficar
> sobrecarregado?"

Decisão tomada com o usuário: usar **OpenRouter** como provedor secundário, com um
modelo gratuito (`nvidia/nemotron-3.5-lightning:free` inicialmente).

Em algum momento entre sessões, a arquitetura foi reorganizada para o formato atual:

**Anthropic (primário) → OpenRouter (fallback) → Mock (sem nenhuma chave)**

Isso ficou registrado no `ai_client.py`, que hoje é uma classe única `AIClient`
(com o alias `ClaudeClient = AIClient` para compatibilidade com o `dockwidget.py` e
`__init__.py`, que foram escritos esperando esse nome).

### 2.3 Expansão do conjunto de ações (pedido: "a lista de comandos é muito pequena")

> "a lista de comandos que o plugin aceita é muito pequena, teria como colocar os
> comandos mais usados do qgis ou todos os comandos?"

Diagnóstico: o `SYSTEM_PROMPT` enviado à IA já *descrevia* várias ações (como
`run_difference`, `run_union`, `run_dissolve`, `export_layout_image`, `filter_layer`,
`clear_filter`) que **existiam como função Python mas não estavam registradas** no
dicionário `ACTIONS` do `executor.py` — ou seja, a IA tentava usá-las e recebia
"Ação não permitida".

O que foi feito:

- `executor.py`: o dicionário `ACTIONS` foi expandido de **7** para **29** entradas,
  organizadas por categoria (camadas, geoprocessamento, layout, expressões).
- `actions/layers.py`: adicionadas as funções `add_vector_layer`, `add_raster_layer`,
  `remove_layer`, `zoom_to_layer`, `export_layer`, `rename_layer` e o helper interno
  `_get_layer`.
- `actions/processing.py`: adicionadas `run_clip`, `run_merge_layers`,
  `run_reproject`, `run_centroids`, `run_convex_hull`, `run_simplify`,
  `run_spatial_join`.
- **Acesso genérico**: foram criadas as funções `run_algorithm(algorithm_id, params,
  output_name)` e `list_algorithms(search_text)`, que usam
  `QgsApplication.processingRegistry()` para listar e executar **qualquer** algoritmo
  de Processing instalado no QGIS — não só os ~12 dedicados. O `SYSTEM_PROMPT` foi
  reescrito para instruir a IA a usar essa rota genérica sempre que o pedido não
  corresponder a uma ação dedicada, em vez de dizer que "não é possível".

Com isso, o plugin passou a cobrir, na prática, todo o catálogo de geoprocessamento
vetorial do QGIS, não apenas uma lista fixa de ~10 comandos.

### 2.4 Bugs encontrados e corrigidos nesta sessão

Durante os testes da expansão de ações, apareceram (e foram corrigidos) os
seguintes problemas:

1. **`AttributeError: 'AIClient' object has no attribute 'ask_claude'`** — o
   `dockwidget.py` chama `self.claude_client.ask_claude(...)`, mas a classe só tinha
   um método `.ask(...)`. Corrigido renomeando o método em `ai_client.py`.
   *(Nota: ao preparar esta release v1.0.0, foi descoberto que a cópia "mestre" do
   `dockwidget.py` em `C:\Users\User\qgis_claude_ai\` ainda chamava `.ask(...)`,
   desatualizada em relação às cópias realmente instaladas no perfil do QGIS — foi
   corrigida para `.ask_claude(...)` também, deixando as três cópias consistentes.)*

2. **Modelo Anthropic desatualizado + parâmetro incompatível** — o código usava
   `model="claude-3-5-sonnet-20241022"` e passava `temperature=0.1`, incompatível
   com a versão do SDK `anthropic` instalada. Corrigido para `model="claude-sonnet-5"`
   e removido o `temperature`.

3. **Respostas mock mascarando o problema real** — comandos diferentes (ex.: "divida
   a camada em duas partes" e "calcule o centroide da camada") estavam retornando a
   mesma resposta (`list_layers`), porque o pipeline estava silenciosamente caindo
   até o modo mock (que só reconhece algumas palavras-chave como `"camada"`).
   Causa raiz: o pacote Python `openai` não estava instalado no Python embutido do
   QGIS, e a variável `OPENROUTER_API_KEY` não estava definida — então nem Anthropic
   (sem crédito) nem OpenRouter (sem biblioteca/chave) funcionavam.

4. **`__init__.py` com resquício do Gemini** — o método `get_claude_client()` ainda
   lia `GEMINI_API_KEY`/`GOOGLE_API_KEY` e mostrava um aviso mencionando essas
   variáveis, mesmo o `ai_client.py` já não usando mais o Gemini. Corrigido para
   checar `ANTHROPIC_API_KEY`/`OPENROUTER_API_KEY` e explicar o modo mock.

5. **Variável de ambiente criada com o nome errado** — o usuário criou a variável do
   Windows com o nome `OPENROUD_QGIS` em vez de `OPENROUTER_API_KEY`. Foi corrigida
   lendo o valor diretamente do registro do Windows (sem nunca expor o valor da
   chave) e regravando sob o nome correto.

6. **QGIS não enxergava a variável de ambiente nova mesmo após reiniciar** —
   descoberto que abrir o QGIS por automação (fora do fluxo normal do Explorer do
   Windows) herda um "retrato" antigo do ambiente do processo, que não é atualizado
   por `setx` nem por um broadcast de `WM_SETTINGCHANGE`. A solução foi o usuário
   fechar e reabrir o QGIS manualmente clicando no ícone — esse caminho passa pelo
   Explorer do Windows, que reflete o ambiente atualizado.

7. **Modelo gratuito da OpenRouter hardcoded** — o código usava um único nome de
   modelo fixo (`nvidia/nemotron-3.5-lightning:free`), que pode deixar de existir ou
   ficar indisponível. Foi adicionado `_discover_free_openrouter_models()` em
   `ai_client.py`, que consulta a lista de modelos da OpenRouter em tempo real,
   filtra os que terminam em `:free`, prioriza alguns conhecidos como mais estáveis
   e tenta a lista em sequência até um responder com sucesso.

### 2.5 Teste de ponta a ponta (confirmado funcionando)

Com tudo corrigido, o teste "liste as camadas do projeto" no painel do plugin
mostrou o comportamento esperado:

```
[AIClient] Anthropic falhou: Error code: 400 — Your credit balance is too low...
  — tentando OpenRouter...
Claude: Plano: { "steps": [ { "action": "list_layers", "params": {} } ] }
✅ Passo 1: []
```

Ou seja: Anthropic falhou (sem crédito), o fallback para OpenRouter com modelo
gratuito funcionou automaticamente, e o plano retornado foi executado com sucesso.

---

## 3. Arquitetura final dos provedores de IA

`ai_client.AIClient`:

- **`__init__`**: lê `ANTHROPIC_API_KEY` e `OPENROUTER_API_KEY` do ambiente. Cria o
  cliente Anthropic e/ou o cliente OpenAI-compatível apontando para
  `https://openrouter.ai/api/v1`, conforme as chaves disponíveis.
- **`ask_claude(prompt, context_layers)`**: ponto de entrada único (nome mantido por
  compatibilidade com `dockwidget.py`). Tenta, em ordem:
  1. `_ask_anthropic` (modelo `claude-sonnet-5`);
  2. `_ask_openrouter` (descobre e tenta modelos gratuitos via
     `_discover_free_openrouter_models`);
  3. `_mock_plan` (respostas simuladas por palavra-chave, só para teste sem chave).
- Cada falha é logada no console do QGIS (`print`) antes de cair para o próximo
  provedor — útil para depuração.
- **Nunca** imprime ou expõe o valor das chaves de API.

---

## 4. Segurança

- A IA só pode chamar ações presentes no dicionário `executor.ACTIONS` — não existe
  caminho para executar código Python arbitrário vindo da resposta da IA.
- Chaves de API vêm exclusivamente de variáveis de ambiente, nunca de arquivo
  versionado no repositório.
- O acesso genérico (`run_algorithm`) ainda passa por `processing.run(...)` do
  próprio QGIS, então herda as mesmas validações de parâmetros do Processing.

---

## 5. Como continuar a partir daqui

Ideias para versões futuras (não implementadas em v1.0.0):

- Página de configurações no próprio plugin para digitar as chaves de API sem mexer
  em variáveis de ambiente do sistema operacional.
- Suporte a mais provedores de IA (ex.: Gemini voltar como mais um fallback).
- Histórico de conversas persistente entre sessões do QGIS.
- Testes automatizados para as funções em `actions/`.
- Preencher `author`, `email` e `repository` em `metadata.txt` com os dados reais do
  mantenedor antes de publicar no repositório oficial de plugins do QGIS.
