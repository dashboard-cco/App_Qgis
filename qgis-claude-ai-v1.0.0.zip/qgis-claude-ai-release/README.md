# Claude AI Assistant para QGIS

Plugin para o [QGIS](https://qgis.org) (3.40+) que adiciona um painel de chat onde você
pede, em português mesmo, para a IA executar ações de geoprocessamento no seu projeto —
criar buffer, interseção, dissolver, reprojetar, filtrar camadas, exportar mapas, e
praticamente qualquer algoritmo da caixa de ferramentas **Processing** do QGIS.

A IA nunca executa código Python livre: ela só pode chamar ações de uma lista fixa e
auditável (`executor.py`), cada uma mapeada para uma função Python segura e específica.

## Como funciona

1. Você digita um pedido no painel ("crie um buffer de 100m na camada vias e salve como
   buffer_vias").
2. O plugin manda o pedido pra um provedor de IA, que responde com um **plano em JSON**:
   uma lista de passos, cada um com um nome de ação e parâmetros.
3. O `executor.py` valida cada ação contra uma lista branca (`ACTIONS`) e executa a
   função PyQGIS correspondente.
4. O resultado de cada passo aparece no chat.

## Provedores de IA (com fallback automático)

O plugin tenta, nesta ordem, até um responder:

1. **Anthropic (Claude)** — se `ANTHROPIC_API_KEY` estiver definida.
2. **OpenRouter**, usando automaticamente um modelo **gratuito** disponível no momento
   (a lista de modelos `:free` é consultada ao vivo na API da OpenRouter) — se
   `OPENROUTER_API_KEY` estiver definida.
3. **Mock** (respostas simuladas, só reconhece alguns padrões simples) — usado quando
   nenhuma chave está configurada ou quando as duas chamadas acima falham. Serve para
   testar a interface sem gastar API.

Ver `DOCUMENTACAO.md` para o histórico completo de como essa arquitetura foi construída.

## Instalação

1. Copie a pasta `qgis_claude_ai/` para a pasta de plugins do seu perfil do QGIS:
   - Windows: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
2. No QGIS, instale as dependências Python do plugin (uma vez só):
   ```
   pip install -r qgis_claude_ai/requirements.txt
   ```
   (no Windows, rode isso no **OSGeo4W Shell** ou use
   `python -m pip install --target <pasta_do_python_do_qgis> -r requirements.txt`)
3. Defina ao menos uma das variáveis de ambiente antes de abrir o QGIS:
   - `ANTHROPIC_API_KEY`
   - `OPENROUTER_API_KEY`

   No Windows: Painel de Controle → Sistema → Configurações avançadas do sistema →
   Variáveis de Ambiente → Nova (em "Variáveis de usuário").

   ⚠️ **Importante**: se o QGIS já estava aberto quando você criou a variável, feche e
   abra o QGIS de novo clicando no ícone normalmente. Reiniciar só o projeto não basta —
   o processo precisa ser recriado para enxergar a variável nova.
4. Em **Complementos → Gerenciar e Instalar Complementos**, ative o plugin
   "Claude AI Assistant" (ou reinicie o QGIS se ele já estava instalado).
5. Clique no ícone "Claude AI Assistant" na barra de ferramentas para abrir o painel.

## Ações disponíveis (resumo)

| Categoria | Ações |
|---|---|
| Camadas | `list_layers`, `select_by_expression`, `create_memory_layer`, `add_vector_layer`, `add_raster_layer`, `remove_layer`, `zoom_to_layer`, `export_layer`, `rename_layer` |
| Geoprocessamento | `run_buffer`, `run_intersection`, `run_difference`, `run_union`, `run_dissolve`, `run_clip`, `run_merge_layers`, `run_reproject`, `run_centroids`, `run_convex_hull`, `run_simplify`, `run_spatial_join` |
| Genérico (qualquer algoritmo do Processing) | `run_algorithm`, `list_algorithms` |
| Layout / exportação | `export_layout_pdf`, `export_layout_image`, `list_layouts` |
| Atributos / expressões | `calculate_field`, `filter_layer`, `clear_filter` |

Quando o pedido não bate com nenhuma ação dedicada, a IA é instruída a usar
`list_algorithms` para procurar o algoritmo certo do Processing e depois
`run_algorithm` para executá-lo — ou seja, na prática o plugin cobre **todo** o catálogo
de geoprocessamento do QGIS, não só a lista acima.

## Segurança

- A IA nunca recebe permissão para rodar código Python arbitrário.
- Toda ação passa por uma lista branca (`executor.ACTIONS`) antes de ser executada.
- Nenhuma chave de API fica no código — tudo vem de variáveis de ambiente.

## Licença

MIT — veja `LICENSE`.

## Status

**v1.0.0** — primeira versão publicada. Testado no QGIS 3.44 (Windows).
