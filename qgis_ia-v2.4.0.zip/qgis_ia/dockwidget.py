# -*- coding: utf-8 -*-
"""
Dock Widget principal - Interface de chat
"""
import json
from qgis.PyQt.QtWidgets import (
    QDockWidget, QVBoxLayout, QWidget, QTextEdit, QLineEdit,
    QPushButton, QHBoxLayout, QLabel, QComboBox, QMessageBox,
    QGroupBox, QCheckBox, QApplication
)
from qgis.PyQt.QtCore import Qt, pyqtSignal, QThread, QObject
from qgis.core import QgsProject, QgsMessageLog

from .executor import execute_plan


class WorkerSignals(QObject):
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)
    progress = pyqtSignal(str)


class AiWorker(QThread):
    """Thread só para a chamada de rede à IA (não trava a UI do QGIS).

    A execução do plano NÃO acontece aqui: a API do QGIS (projeto, camadas,
    iface) só é segura no thread principal. Quem executa é on_worker_finished.
    """
    def __init__(self, claude_client, prompt, context_layers):
        super().__init__()
        self.claude_client = claude_client
        self.prompt = prompt
        self.context_layers = context_layers
        self.signals = WorkerSignals()

    def run(self):
        try:
            # Pede plano à IA (Anthropic → OpenRouter → Mock)
            plan = self.claude_client.ask_claude(self.prompt, self.context_layers)
            self.signals.progress.emit(f"Plano recebido: {len(plan.get('steps', []))} passo(s)")
            self.signals.finished.emit({"plan": plan})
        except Exception as e:
            import traceback
            self.signals.error.emit(traceback.format_exc())


class QgisIaDockWidget(QDockWidget):
    closed = pyqtSignal()

    def __init__(self, iface, claude_client, mcp_server=None):
        super().__init__("QGIS_IA", iface.mainWindow())
        self.iface = iface
        self.claude_client = claude_client
        self.mcp_server = mcp_server
        self.worker = None
        self.setup_ui()
        if self.mcp_server is not None:
            self.mcp_server.status_changed.connect(self.on_mcp_status)
            self.mcp_server.log.connect(self.on_mcp_log)
            self.on_mcp_status(
                f"Servidor ativo na porta {self.mcp_server.port}."
                if self.mcp_server.is_running() else "Servidor parado."
            )

    def setup_ui(self):
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setMinimumWidth(380)

        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        # Header
        header = QHBoxLayout()
        header.addWidget(QLabel("🤖"))
        header.addWidget(QLabel("<b>QGIS_IA</b>"))
        header.addStretch()
        layout.addLayout(header)

        # Lista de camadas (contexto)
        self.layer_combo = QComboBox()
        self.layer_combo.addItem("Todas as camadas")
        self.refresh_layers()
        layout.addWidget(QLabel("Contexto:"))
        layout.addWidget(self.layer_combo)

        # Chat area
        self.chat_log = QTextEdit()
        self.chat_log.setReadOnly(True)
        self.chat_log.setStyleSheet("""
            QTextEdit { background: #1e1e1e; color: #d4d4d4; font-family: Consolas, monospace; font-size: 12px; }
        """)
        layout.addWidget(self.chat_log)

        # Input area
        input_layout = QHBoxLayout()
        self.prompt_input = QLineEdit()
        self.prompt_input.setPlaceholderText("Ex: 'Crie buffer de 100m na camada vias e salve como buffer_vias'")
        self.prompt_input.returnPressed.connect(self.send_prompt)
        input_layout.addWidget(self.prompt_input)

        self.send_btn = QPushButton("Enviar")
        self.send_btn.clicked.connect(self.send_prompt)
        input_layout.addWidget(self.send_btn)
        layout.addLayout(input_layout)

        # Status
        self.status_label = QLabel("Pronto. Digite um comando acima.")
        self.status_label.setStyleSheet("color: #888; font-size: 11px;")
        layout.addWidget(self.status_label)

        # Servidor MCP (permite o Claude Desktop / Claude Code controlarem o QGIS)
        if self.mcp_server is not None:
            box = QGroupBox("Servidor MCP (Claude Desktop / Claude Code)")
            box_layout = QVBoxLayout(box)

            self.mcp_btn = QPushButton("Iniciar servidor")
            self.mcp_btn.clicked.connect(self.toggle_mcp)
            box_layout.addWidget(self.mcp_btn)

            self.mcp_readonly = QCheckBox("Somente leitura (bloqueia ações que gravam ou removem)")
            self.mcp_readonly.toggled.connect(self.mcp_server.set_read_only)
            box_layout.addWidget(self.mcp_readonly)

            self.mcp_allow_code = QCheckBox("Permitir execução de código Python (avançado)")
            self.mcp_allow_code.setToolTip(
                "Libera a ferramenta execute_code. Com ela, quem estiver conectado "
                "pode rodar qualquer PyQGIS, inclusive ler e apagar arquivos.")
            self.mcp_allow_code.toggled.connect(self.on_allow_code)
            box_layout.addWidget(self.mcp_allow_code)

            copy_row = QHBoxLayout()
            code_btn = QPushButton("Copiar comando (Claude Code)")
            code_btn.clicked.connect(self.copy_claude_code_command)
            desktop_btn = QPushButton("Copiar JSON (Claude Desktop)")
            desktop_btn.clicked.connect(self.copy_claude_desktop_json)
            copy_row.addWidget(code_btn)
            copy_row.addWidget(desktop_btn)
            box_layout.addLayout(copy_row)

            self.mcp_status = QLabel("Servidor parado.")
            self.mcp_status.setStyleSheet("color: #888; font-size: 11px;")
            box_layout.addWidget(self.mcp_status)
            layout.addWidget(box)

        self.setWidget(main_widget)

    # --- Servidor MCP ----------------------------------------------------
    def toggle_mcp(self):
        if self.mcp_server.is_running():
            self.mcp_server.stop()
        else:
            self.mcp_server.start()

    def on_mcp_status(self, msg):
        self.mcp_status.setText(msg)
        self.mcp_btn.setText("Parar servidor" if self.mcp_server.is_running() else "Iniciar servidor")

    def on_mcp_log(self, msg):
        QgsMessageLog.logMessage(msg, "QGIS_IA")
        self.append_chat("🔌", msg)

    def on_allow_code(self, checked):
        if checked:
            answer = QMessageBox.warning(
                self, "QGIS_IA",
                "Isto libera a execução de código Python arbitrário no QGIS.\n\n"
                "Quem estiver conectado ao servidor poderá fazer qualquer coisa que o "
                "QGIS faz, inclusive ler e apagar arquivos do seu computador.\n\n"
                "Deseja continuar?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                self.mcp_allow_code.setChecked(False)
                return
        self.mcp_server.set_allow_code(checked)

    def copy_claude_code_command(self):
        python = self.mcp_server.python_path()
        path = self.mcp_server.bridge_path()
        cmd = f'claude mcp add -s user qgis-ia -- "{python}" "{path}"'
        QApplication.clipboard().setText(cmd)
        self.mcp_status.setText("Comando copiado. Cole no terminal e tecle Enter.")

    def copy_claude_desktop_json(self):
        python = self.mcp_server.python_path()
        path = self.mcp_server.bridge_path()
        cfg = {"mcpServers": {"qgis-ia": {"command": python, "args": [path]}}}
        QApplication.clipboard().setText(json.dumps(cfg, indent=2, ensure_ascii=False))
        self.mcp_status.setText("JSON copiado. Cole no claude_desktop_config.json.")

    def refresh_layers(self):
        self.layer_combo.clear()
        self.layer_combo.addItem("Todas as camadas")
        for layer in QgsProject.instance().mapLayers().values():
            self.layer_combo.addItem(layer.name(), layer.id())

    def get_context_layers(self):
        if self.layer_combo.currentIndex() == 0:
            return [l.name() for l in QgsProject.instance().mapLayers().values()]
        return [self.layer_combo.currentText()]

    def send_prompt(self):
        prompt = self.prompt_input.text().strip()
        if not prompt:
            return

        self.prompt_input.clear()
        self.append_chat("👤 Você", prompt)
        self.status_label.setText("Enviando para Claude...")
        self.send_btn.setEnabled(False)

        # Inicia worker
        self.worker = AiWorker(self.claude_client, prompt, self.get_context_layers())
        self.worker.signals.finished.connect(self.on_worker_finished)
        self.worker.signals.error.connect(self.on_worker_error)
        self.worker.signals.progress.connect(self.on_worker_progress)
        self.worker.start()

    def on_worker_progress(self, msg):
        self.status_label.setText(msg)

    def on_worker_finished(self, data):
        self.send_btn.setEnabled(True)
        plan = data["plan"]

        for warning in getattr(self.claude_client, "last_warnings", []):
            self.append_chat("⚠️", warning)

        explanation = plan.get("explanation")
        if explanation:
            self.append_chat("🤖 Claude", explanation)
        if not plan.get("steps"):
            self.status_label.setText("Nada a executar.")
            return

        self.append_chat("🤖 Claude", f"Plano: {json.dumps(plan, ensure_ascii=False, indent=2)}")

        # Executa no thread principal (slot de sinal do QThread roda aqui)
        self.status_label.setText("Executando plano no QGIS...")
        results = execute_plan(plan)

        for i, res in enumerate(results):
            if res.get("success"):
                self.append_chat("✅", f"Passo {i+1}: {res.get('result', 'OK')}")
            else:
                self.append_chat("❌", f"Passo {i+1} FALHOU: {res.get('error')}")

        self.status_label.setText("Concluído.")

    def on_worker_error(self, err):
        self.send_btn.setEnabled(True)
        self.append_chat("❌ Erro", err)
        self.status_label.setText("Erro - veja log.")

    def append_chat(self, sender, text):
        self.chat_log.append(f"<b>{sender}:</b> {text}")
        # Auto-scroll
        self.chat_log.verticalScrollBar().setValue(
            self.chat_log.verticalScrollBar().maximum()
        )

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.terminate()
            self.worker.wait()
        self.closed.emit()
        super().closeEvent(event)